# code repository for Rodriguez et al. 2017
NN paper "A craniofacial-specific monosynaptic circuit enables heightened affective pain"

Read the instruction documents or wiki pages to run the scripts. 
